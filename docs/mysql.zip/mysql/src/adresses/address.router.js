const express = require('express');

const router = express.Router();

const  userController = require('./address.controller');

router.get('/getall', userController.getAlls);

router.get('/get/:id', userController.getAddress);

router.post('/add', userController.createAddress);

router.put('/update/:id', userController.updateAddress);

router.delete('/delete/:id', userController.deleteAddress);


module.exports = router;