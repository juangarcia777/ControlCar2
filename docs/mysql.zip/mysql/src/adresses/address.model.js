const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
  user:String,
  typeUser: {
    type: String,
    required: true,
  },
  state: {
    type: String,
    required: true,
  },
  city: {
    type: String,
    required: true,
  },
  street: {
    type: String,
    required: true,
  },
  neighborhood: {
    type: String,
    required: true,
  },
  number:{
    type: String,
    required: true,
  },
  complement:{
    type: String,
    required: true,
  },
  reference:{
    type: String,
    required: true,
  },
  phone:{
    type: String,
    required: true,
  }

})

const Adresses = mongoose.model("Adresses", UserSchema);

module.exports = Adresses;