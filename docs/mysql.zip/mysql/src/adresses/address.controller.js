const mongoose = require("mongoose");
let Address = require('./address.model');

exports.getAlls = async (req, res)=>{
  try {
    let address = await Address.find({});
    if(address){
      return res.status(202).json(address);
    }else{
      return res.status(400).json({message: 'Erro ao tentar buscar no banco'})
    }

  } catch (error) {
    return res.status(400).json(error);
  }
}

exports.getAddress = async (req, res)=>{
  try {
    
  const addressId = req.params.id;
  

  let address = await Address.findById(addressId);
  
  if(address){
    return res.status(200).json(address);
  }else{
    return res.status(400).json({message: 'Erro ao tentar buscar endereco no banco'})
  }
  } catch (error) {
    return res.status(400).json(error);
  }
}

exports.updateAddress = async (req, res)=>{
  try {
  const addressId = req.params.id;
  
  const address = req.body;
  
  const addressUpdate = await Address.findByIdAndUpdate(mongoose.Types.ObjectId(addressId), {$set: address}, {new: true});
  
  if(addressUpdate){
    return res.status(202).json({message: 'Address Update', data: addressUpdate});
  }else{
    return res.status(400).json({message: 'An error has occured! Address not updated!'})
  }
    
  } catch (error) {
    return res.status(400).json(error);
  }
}

exports.createAddress = async (req, res)=>{
  try {
    let {user, typeUser, state, city, street, neighborhood, number, complement, reference, phone} = req.body;
    let address = await Address.create({
      user, typeUser, state, city, street, neighborhood, number,complement, reference, phone});
    if(address){
      return res.status(202).json(address);
    }else{
      return res.status(400).json({message: 'Erro ao tentar criar endereço no banco'})
    }

  } catch (error) {
    return res.status(400).json(error);
  }
}

exports.deleteAddress = async (req, res)=>{
    try {
      let {id} = req.body;

      let address = await Address.deleteOne({id})

      if(address){
        return res.status(202).json(address);
      }else{
        return res.status(400).json({message: 'Erro ao deletar endereço no banco'})
      }
    } catch (error) {
      
    }
}
