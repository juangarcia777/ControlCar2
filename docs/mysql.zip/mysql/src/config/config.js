let config = {
  port: 3000, //Porta da aplicação
  secret: "49fb775afa045a8d97a4ddba26c725cb", //código que acompanha token   
  timer: 1562271258 //
}