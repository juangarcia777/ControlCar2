const express = require('express');
const useRouter = require('../user/user.router');
//const addressRouter = require('../Adresses/address.router');


module.exports = (app) =>{
  //rotas da aula
  app.use('/user', useRouter);
 


  app.use('/', (req,res)=>{
    res.send('Bem vindo a nossa Api!');
  });

}